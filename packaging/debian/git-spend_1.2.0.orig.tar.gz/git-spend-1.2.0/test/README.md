Acceptance (integration) tests are in the `feature.bats` file.

_bats_ and _test helpers_ are loaded as submodules.

Try:

    make test-depend
    make test-acceptance

